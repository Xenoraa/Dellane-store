﻿using Dellane_store.API.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Dellane_store.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomerController : ControllerBase
    {
        private readonly StoreContext _context;

        public CustomerController(StoreContext context)
        {
            _context = context;
            _context.Database.EnsureCreated();
        }

        [HttpGet("customers")]
        public async Task<ActionResult> GetAllCustomers()
        {
            var customers = await _context.Customers.ToListAsync();
            return Ok(customers);  
        }

        
        [HttpGet("customers/{id}")]
        public async Task<ActionResult> GetCustomer(int id)
        {
            var customer = await _context.Customers.FindAsync(id);  // Look for customer by ID
            if (customer == null)
            {
                return NotFound();  // Return 404 if not found
            }
            return Ok(customer);  // Return the customer data
        }

        // Post a new customer
        [HttpPost("customers")]
        public async Task<ActionResult<Customer>> PostCustomer(Customer customer)
        {
            if (customer == null)
            {
                return BadRequest("Customer data is required.");
            }

            _context.Customers.Add(customer);  // Add new customer to DB
            await _context.SaveChangesAsync();  // Save changes

            // Return the created customer with a 201 Created response
            return CreatedAtAction(
                "GetCustomer",
                new { id = customer.Id },
                customer);
        }

        // Delete a customer by ID
        [HttpDelete("customers/{id}")]
        public async Task<ActionResult<Customer>> DeleteCustomer(int id)
        {
            var customer = await _context.Customers.FindAsync(id);  // Look for customer by ID
            if (customer == null)
            {
                return NotFound();  // Return 404 if customer not found
            }

            _context.Customers.Remove(customer);  // Remove the customer from DB
            await _context.SaveChangesAsync();  // Save changes

            return customer;  // Return the deleted customer
        }

        // Update an existing customer
        [HttpPut("customers/{id}")]
        public async Task<ActionResult> PutCustomer(int id, Customer customer)
        {
            if (id != customer.Id)
            {
                return BadRequest("Customer ID mismatch.");  // Return 400 if ID in URL and body don't match
            }

            _context.Entry(customer).State = EntityState.Modified;  // Mark customer as modified

            try
            {
                await _context.SaveChangesAsync();  // Save changes to DB
            }
            catch (DbUpdateConcurrencyException)
            {
                // Check if customer still exists in DB
                if (!_context.Customers.Any(p => p.Id == id))
                {
                    return NotFound();  // Return 404 if not found
                }
                else
                {
                    throw;  // Rethrow exception if there's a concurrency issue
                }
            }

            return NoContent();  // Return 204 No Content if update is successful
        }
    }
}
