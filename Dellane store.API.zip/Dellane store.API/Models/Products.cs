﻿using System.ComponentModel.DataAnnotations;
using System.Runtime.InteropServices.Marshalling;
using System.Text.Json.Serialization;

namespace Dellane_store.API.Models
{
    public class Products
    {
        [Key]
        public int Id { get; set; }
        public string ProductName { get; set; } = string.Empty;
        [StringLength(100)]
        public string ProductDescription { get; set; } = string.Empty;
        public string ProductCategory { get; set; }
        public decimal Price { get; set; }
        public bool IsAvailable { get; set; }

        [Required]
        public int CategoryId { get; set; }

        [JsonIgnore]
        public virtual Category? Category { get; set; }
        [JsonIgnore]
        public virtual Customer? Customer { get; set; }
       
    }
}
