﻿using Microsoft.EntityFrameworkCore;
using System.Runtime.CompilerServices;

namespace Dellane_store.API.Models
{
    public static class ModelBuilderExtensions
    {

        public static void Seed(this ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Customer>().HasData(
                new Customer { Id = 001, FirstName = "Anne", LastName = "Gatsby", Address = "lugbe,Abuja", Email = "itsanne@gmail.com" }
);
            modelBuilder.Entity<Category>().HasData(
               new Category { Id = 1, Name = "bracelets" },
               new Category { Id = 2, Name = "Anklet" },
               new Category { Id = 3, Name = "Earrings" },
               new Category { Id = 4, Name = "Rings" },
               new Category { Id = 5, Name = "Necklace" });
            modelBuilder.Entity<Products>().HasData(
                new Products { Id = 1, ProductName = "sasha", ProductCategory = "bracelets", Price = 68, IsAvailable = true },
                new Products { Id = 2, ProductName = "ash", ProductCategory = "Rings", Price = 35, IsAvailable = true }
                );
        }
    };
}

